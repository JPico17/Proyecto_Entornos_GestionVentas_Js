import React from 'react';

const Administracion: React.FC = () => {
    return (
        <div>
            <h1>Hola Mundo</h1>
        </div>
    );
};

export default Administracion;