document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const mensaje = document.getElementById('mensaje');

  try {
    const response = await fetch('http://localhost:9090/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (!response.ok) {
      const error = await response.json();
      mensaje.textContent = error.mensaje || 'Credenciales inválidas';
      mensaje.style.color = 'red';
      return;
    }

    const data = await response.json();
    mensaje.textContent = data.mensaje;
    mensaje.style.color = 'green';

    // Guardar info en localStorage
    localStorage.setItem('usuario', JSON.stringify(data));

    // Redirigir según rol
    if (data.rol === 'ADMIN') {
      window.location.href = 'admin.html';
    } else {
      window.location.href = 'empleado.html';
    }

  } catch (error) {
    console.error('Error:', error);
    mensaje.textContent = 'Error de conexión con el servidor';
    mensaje.style.color = 'red';
  }
});



