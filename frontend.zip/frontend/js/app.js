(() => {
  const qs = (s, el = document) => el.querySelector(s);

  // 🔐 Leer rol guardado
  const role = localStorage.getItem("role");
  const navbar = qs("#navbar");
  const content = qs("#dynamicContent");

  // 🌓 Tema
  const theme = localStorage.getItem("theme") || "light";
  document.documentElement.setAttribute("data-theme", theme);

  // 🧭 Navbar dinámico según rol
  function renderNavbar() {
    if (role === "ADMIN") {
      navbar.innerHTML = `
        <div class="container nav-inner">
          <a href="#" class="brand"><span class="tag">ADMIN</span> Gestión de Ventas</a>
          <div class="nav-links">
            <a href="#" id="btnDashboard" class="btn">Dashboard</a>
            <a href="#" id="btnEmpleados" class="btn">Empleados</a>
            <a href="#" id="btnProductos" class="btn">Productos</a>
            <button id="themeToggle" class="btn ghost">🌗</button>
            <button id="logoutBtn" class="btn">Cerrar sesión</button>
          </div>
        </div>
      `;
    } else {
      navbar.innerHTML = `
        <div class="container nav-inner">
          <a href="#" class="brand"><span class="tag">Empleado</span> Gestión de Ventas</a>
          <div class="nav-links">
            <a href="#" id="btnInventario" class="btn">Inventario</a>
            <a href="#" id="btnVentas" class="btn">Ventas</a>
            <button id="themeToggle" class="btn ghost">🌗</button>
            <button id="logoutBtn" class="btn">Cerrar sesión</button>
          </div>
        </div>
      `;
    }

    // Eventos comunes
    qs("#logoutBtn").addEventListener("click", () => {
      localStorage.clear();
      window.location.href = "login.html";
    });

    qs("#themeToggle").addEventListener("click", () => {
      const cur = document.documentElement.getAttribute("data-theme");
      const next = cur === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem("theme", next);
    });
  }

  // 🧩 Contenido para ADMIN
  function renderAdminDashboard() {
    content.innerHTML = `
      <section>
        <h2>📊 Panel de Administración</h2>
        <p>Bienvenido administrador. Aquí puedes gestionar empleados, productos y ver estadísticas.</p>
        <div class="grid cols-3">
          <div class="card"><h3>Total de Empleados</h3><p id="totalEmpleados">...</p></div>
          <div class="card"><h3>Total de Productos</h3><p id="totalProductos">...</p></div>
          <div class="card"><h3>Ventas Hoy</h3><p id="ventasHoy">...</p></div>
        </div>
      </section>
    `;
    // Aquí puedes hacer fetchs reales si tienes tu API
    cargarKPIs();
  }

  // 🧩 Contenido para EMPLOYEE
  function renderEmployeeHome() {
    content.innerHTML = `
      <section>
        <h2>🛒 Módulo de Ventas</h2>
        <p>Bienvenido empleado. Aquí puedes ver los productos y registrar ventas.</p>
        <table class="table">
          <thead>
            <tr><th>ID</th><th>Producto</th><th>Precio</th><th>Stock</th></tr>
          </thead>
          <tbody id="productosBody"></tbody>
        </table>
      </section>
    `;
    cargarProductos();
  }

  // 📈 Ejemplo de carga de KPIs (mock o API real)
  async function cargarKPIs() {
    const empleados = await fetch("http://localhost:9090/api/empleados").then(r => r.json());
    const productos = await fetch("http://localhost:9090/api/productos").then(r => r.json());

    qs("#totalEmpleados").textContent = empleados.length;
    qs("#totalProductos").textContent = productos.length;
    qs("#ventasHoy").textContent = "$3.250.000 (demo)";
  }

  // 🧾 Cargar productos para empleados
  async function cargarProductos() {
    const res = await fetch("http://localhost:9090/api/productos");
    const data = await res.json();
    const tbody = qs("#productosBody");
    tbody.innerHTML = data.map(p => `
      <tr>
        <td>${p.id}</td>
        <td>${p.nombre}</td>
        <td>$${p.precio.toLocaleString('es-CO')}</td>
        <td>${p.stock}</td>
      </tr>
    `).join('');
  }

  // 🕓 Año actual
  qs("#year").textContent = new Date().getFullYear();

  // 🚀 Inicializar vista
  renderNavbar();
  if (role === "ADMIN") renderAdminDashboard();
  else renderEmployeeHome();
})();
